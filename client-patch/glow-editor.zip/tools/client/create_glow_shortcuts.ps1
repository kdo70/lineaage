$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path "$PSScriptRoot\..\..").Path
$clientRoot = Join-Path $projectRoot 'client\build'
$shell = New-Object -ComObject WScript.Shell
$normal = $shell.CreateShortcut((Join-Path $clientRoot 'Lineage II.lnk'))
$normal.TargetPath = Join-Path $clientRoot 'system\L2.exe'
$normal.WorkingDirectory = Join-Path $clientRoot 'system'
$normal.Save()
$dev = $shell.CreateShortcut((Join-Path $clientRoot 'Lineage II Dev.lnk'))
$dev.TargetPath = Join-Path $projectRoot 'tools\vendor\python\pythonw.exe'
$dev.Arguments = '"' + (Join-Path $projectRoot 'tools\client\glow_mesh_live.py') + '"'
$dev.WorkingDirectory = Join-Path $clientRoot 'system'
$dev.Save()
