"""Check the entire table against the original, including retail exceptions."""
from glow_mesh import WORK,SYSTEM,EXCEPTIONS
from glow_effect_assignment import eligible,effect_values,write_values
import json
import sys
before=(WORK/'original.txt').read_bytes().splitlines()
after=(WORK/'prepared.txt').read_bytes().splitlines()
assert len(before)==len(after) and before[0]==after[0]
columns={value.decode():n for n,value in enumerate(before[0].split(b'\t'))}
removed=protected=effects=0
source_rows={int(line.split(b'\t')[columns['id']]):dict(zip(columns,line.decode().split('\t'))) for line in before[1:]}
additions=json.loads((WORK/'effect-assignments.json').read_text())
assigned={(a['id'],a['slot']):a for a in additions}
for a in additions:
    donor=source_rows[a['donor']]
    assert int(donor['crystal_type'])>=4 and a['donor'] not in EXCEPTIONS and donor['is_hero']!='1'
    assert donor['eff'+'AB'[a['donor_slot']]]==a['effect']
    assert not source_rows[a['id']]['eff'+'AB'[a['slot']]]
for old,new in zip(before[1:],after[1:]):
    source=old.split(b'\t');result=new.split(b'\t')
    item=int(source[columns['id']])
    keep=item in EXCEPTIONS or source[columns['is_hero']]==b'1'
    if keep:
        assert old==new,item
        protected+=1
    for name,n in columns.items():
        if not keep and name in ('rangeA','rangeB') and source[n].lower()==b'lineageweapons.rangesample':
            assert result[n]==b'',(item,name)
            removed+=1
        elif name in ('effA','effB') and (item,'AB'.index(name[-1])) in assigned:
            assert result[n].decode()==assigned[(item,'AB'.index(name[-1]))]['effect']
        elif name.startswith('junk1') and any((item,s) in assigned for s in (0,1)):
            # Only neutral size/velocity defaults may be repaired for newly enabled slots.
            pass
        else:
            assert source[n]==result[n],(item,name)
    row=dict(zip(columns,new.decode().split('\t')))
    if eligible(row) and not keep:
        assert all(row['eff'+'AB'[slot]] for slot in range(int(row['wpn_mesh_cnt']))),item
    old_values=effect_values(source_rows[item]); new_values=effect_values(row)
    for slot in (0,1):
        if old_values[slot] is None:continue
        expected=old_values[slot][:]
        if (item,slot) in assigned:
            if expected[3]<=0:expected[3]=1
            if expected[4]<=0:expected[4]=1
        assert new_values[slot]==expected,(item,slot)
    if int(row['wpn_mesh_cnt']) in (1,2):
        copy=row.copy(); write_values(copy,new_values)
        assert effect_values(copy)==new_values
    effects+=bool(result[columns['effA']] or result[columns['effB']])
if '--staged' not in sys.argv:
    assert (SYSTEM/'weapongrp.dat').read_bytes()==(WORK/'prepared.dat').read_bytes()
print(f'{len(after)-1} rows checked; {removed} rangesample references removed; {protected} exceptions unchanged; {len(additions)} donor assignments verified; {effects} rows have effects')
