"""Launch one developer client and tune retail mesh vectors in its process."""
import ctypes as C
from ctypes import wintypes as W
import json, struct, subprocess, time, tkinter as tk
import sys
import traceback
from pathlib import Path
from tkinter import ttk, messagebox
from glow_mesh import ROOT, SYSTEM, WORK
sys.path.insert(0,str(ROOT/'tools/python'))
from keystone import Ks, KS_ARCH_X86, KS_MODE_32
from glow_effect_logic import KEYS, SIZE_KEYS, VELOCITY_KEYS, move, adjust_multiplier, hotkeys_enabled, EffectPositionSession

def log_event(event, **fields):
    WORK.mkdir(exist_ok=True)
    with (WORK/'live-session.jsonl').open('a',encoding='utf-8') as output:
        output.write(json.dumps({'time':time.time(),'event':event,**fields},ensure_ascii=False)+'\n')

K = C.WinDLL('kernel32', use_last_error=True)
U = C.WinDLL('user32', use_last_error=True)
N = C.WinDLL('ntdll')
N.NtSuspendProcess.argtypes=[W.HANDLE]
N.NtResumeProcess.argtypes=[W.HANDLE]
N.NtSuspendProcess.restype=W.LONG
N.NtResumeProcess.restype=W.LONG
K.OpenProcess.restype = W.HANDLE
K.VirtualAllocEx.restype = C.c_void_p
K.CreateToolhelp32Snapshot.restype = W.HANDLE
K.ReadProcessMemory.argtypes = [W.HANDLE,C.c_void_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)]
K.WriteProcessMemory.argtypes = [W.HANDLE,C.c_void_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)]
K.VirtualAllocEx.argtypes = [W.HANDLE,C.c_void_p,C.c_size_t,W.DWORD,W.DWORD]
K.VirtualProtectEx.argtypes = [W.HANDLE,C.c_void_p,C.c_size_t,W.DWORD,C.POINTER(W.DWORD)]
K.FlushInstructionCache.argtypes = [W.HANDLE,C.c_void_p,C.c_size_t]
K.CloseHandle.argtypes = [W.HANDLE]

class Module(C.Structure):
    _fields_ = [('size',W.DWORD),('id',W.DWORD),('pid',W.DWORD),('globalUse',W.DWORD),('processUse',W.DWORD),('base',C.c_void_p),('length',W.DWORD),('handle',W.HMODULE),('name',W.WCHAR*256),('path',W.WCHAR*260)]

K.Module32FirstW.argtypes=[W.HANDLE,C.POINTER(Module)]
K.Module32NextW.argtypes=[W.HANDLE,C.POINTER(Module)]
U.GetForegroundWindow.restype=W.HWND
U.GetWindowThreadProcessId.argtypes=[W.HWND,C.POINTER(W.DWORD)]

class Live:
    def __init__(self, process):
        self.process = process
        self.handle = K.OpenProcess(0xc38,False,process.pid)
        if not self.handle: raise C.WinError(C.get_last_error())
        self.base = None
        for _ in range(300):
            if process.poll() is not None: raise RuntimeError('Клиент завершился при запуске')
            snap = K.CreateToolhelp32Snapshot(0x18,process.pid)
            if snap != C.c_void_p(-1).value:
                entry = Module(); entry.size = C.sizeof(entry)
                ok = K.Module32FirstW(snap,C.byref(entry))
                while ok:
                    if entry.name.lower() == 'engine.dll': self.base = entry.base; break
                    ok = K.Module32NextW(snap,C.byref(entry))
                K.CloseHandle(snap)
            if self.base: break
            time.sleep(.1)
        if not self.base: raise RuntimeError('Не найден engine.dll')
        self.target = self.base + 0x1b9870
        self.original = self.read(self.target,5)
        if self.original != bytes.fromhex('558bec6aff'):
            raise RuntimeError('Неизвестная версия обновления свечения; патч не установлен')
        if self.read(self.target+5,5) != b'\x68'+struct.pack('<I',self.base+0x517e0b):
            raise RuntimeError('Версия функции обновления свечения отличается от проверенной')
        self.memory = K.VirtualAllocEx(self.handle,None,4096,0x3000,0x40)
        if not self.memory or self.memory > 0xffffffff: raise RuntimeError('Нет памяти для x86-патча')
        self.buffer = self.memory+2048
        trampoline = self.memory+1024
        self.write(trampoline,self.original+b'\xe9'+struct.pack('<i',self.target+5-trampoline-10))
        assembly = f'''pushfd
pushad
inc dword ptr [{self.buffer+88}]
mov esi, ecx
call {self.base+0x121b1}
test eax, eax
jz done
mov dword ptr [{self.buffer+64}], esi
mov eax, dword ptr [esi+0x6a0]
mov dword ptr [{self.buffer+68}], eax
inc dword ptr [{self.buffer+72}]
mov eax, dword ptr [esi+0x16a4]
mov dword ptr [{self.buffer+76}], eax
mov eax, dword ptr [{self.buffer}]
test eax, eax
jz done
cmp eax, dword ptr [esi+0x6a0]
jne done
mov ebp, dword ptr [esi+0x16a4]
cmp ebp, 16
ja done
mov edx, dword ptr [esi+0x16a0]
test edx, edx
jz done
next_effect:
test ebp, ebp
jz done
dec ebp
mov edi, dword ptr [edx+ebp*4]
test edi, edi
jz next_effect
cmp dword ptr [edi+4], esi
jne next_effect
mov eax, dword ptr [edi+0x20]
dec eax
cmp eax, 1
ja next_effect
cmp dword ptr [{self.buffer+44}], 0
je select_slot
cmp dword ptr [esi+0x16a4], 1
jne select_slot
xor eax, eax
select_slot:
imul eax, eax, 20
lea ebx, [eax+{self.buffer+4}]
push ebx
push edi
add edi, 0x30
mov ecx, 5
check_value:
mov eax, dword ptr [ebx]
cmp eax, dword ptr [edi]
jne changed
add ebx, 4
add edi, 4
loop check_value
pop edi
pop ebx
jmp next_effect
changed:
pop edi
pop ebx
push edi
add edi, 0x30
mov ecx, 5
copy_value:
mov eax, dword ptr [ebx]
mov dword ptr [edi], eax
add ebx, 4
add edi, 4
loop copy_value
pop edi
push edx
mov ecx, edi
call {self.base+0x13da9}
pop edx
inc dword ptr [{self.buffer+80}]
mov eax, dword ptr [edi+8]
mov dword ptr [{self.buffer+84}], eax
jmp next_effect
done:
popad
popfd
jmp {trampoline}'''
        code = bytes(Ks(KS_ARCH_X86,KS_MODE_32).asm(assembly,self.memory)[0])
        self.write(self.memory,code)
        self.write(self.buffer,bytes(96))
        self.patch(b'\xe9'+struct.pack('<i',self.memory-self.target-5))

    def read(self,address,length):
        data=C.create_string_buffer(length); count=C.c_size_t()
        if not K.ReadProcessMemory(self.handle,address,data,length,C.byref(count)) or count.value != length: raise C.WinError(C.get_last_error())
        return data.raw

    def write(self,address,data):
        count=C.c_size_t()
        if not K.WriteProcessMemory(self.handle,address,data,len(data),C.byref(count)) or count.value != len(data): raise C.WinError(C.get_last_error())

    def patch(self,data):
        if N.NtSuspendProcess(self.handle)<0:raise RuntimeError('Не удалось остановить потоки для установки dev-патча')
        try:
            old=W.DWORD()
            if not K.VirtualProtectEx(self.handle,self.target,5,0x40,C.byref(old)): raise C.WinError(C.get_last_error())
            try:
                self.write(self.target,data)
                K.FlushInstructionCache(self.handle,self.target,5)
            finally:
                ignored=W.DWORD(); K.VirtualProtectEx(self.handle,self.target,5,old.value,C.byref(ignored))
        finally:
            N.NtResumeProcess(self.handle)

    def apply(self,item,slots,single_main_effect=False):
        self.write(self.buffer,struct.pack('<I',0))
        self.write(self.buffer+4,struct.pack('<10fI',*(slots[0]+slots[1]),single_main_effect))
        self.write(self.buffer,struct.pack('<I',item))

    def equipped(self):
        return struct.unpack('<7I',self.read(self.buffer+64,28))

def main(executable='L2.exe'):
    catalog=json.loads((WORK/'catalog.json').read_text(encoding='utf-8'))
    saved_file=WORK/'effect-positions.json'
    saved=json.loads(saved_file.read_text(encoding='utf-8')) if saved_file.exists() else {}
    session=EffectPositionSession()
    process=subprocess.Popen([str(SYSTEM/executable),'-INI=devmode.ini','-ng'],cwd=SYSTEM)
    live=Live(process)
    log_event('started',pid=process.pid,hook=live.target,buffer=live.buffer)
    window=tk.Tk(); window.title('Свечение оружия — dev v5'); window.geometry('680x490')
    status=tk.StringVar(); weapon=tk.StringVar(value='Ожидание персонажа…');diagnostic=tk.StringVar()
    ttk.Label(window,textvariable=weapon,wraplength=630).pack(pady=8)
    ttk.Label(window,text='Оружие определяется автоматически. Парные эффекты смещаются вместе.').pack()
    state={'id':None,'slots':None,'sequence':None,'seen':time.monotonic(),'logged':0}; pressed=set()
    def callback_error(kind,value,tb):
        detail=''.join(traceback.format_exception(kind,value,tb))
        log_event('callback_error',detail=detail)
        diagnostic.set('Ошибка управления: '+str(value))
    window.report_callback_exception=callback_error
    def choose(item):
        state['id']=None
        live.apply(0,[[0,0,0,1,1]]*2)
        data=catalog.get(item)
        if data is None or not any(data['slots']):
            weapon.set(f'Оружие ID {item}: ретейльное исключение или нет эффекта LineageEffect')
            status.set('Настройка недоступна');return
        state.update(id=item,slots=session.select(item,data,saved))
        weapon.set(f'ID {item}: {data["mesh"]}')
        update()
    def update():
        if state['id']:
            original = catalog[state['id']]['slots']
            single_main_effect = original[0] is not None and original[1] is None
            live.apply(int(state['id']),state['slots'],single_main_effect)
            status.set('ID '+state['id']+' | XYZ '+str(state['slots'][0][:3])+' | Размер '+str(state['slots'][0][3])+' | Скорость '+str(state['slots'][0][4]))
            log_event('apply',item=state['id'],slots=state['slots'])
    def save():
        if not state['id']:return
        saved[state['id']]=[v[:] for v in state['slots']]
        temporary=saved_file.with_suffix('.tmp'); temporary.write_text(json.dumps(saved,indent=2),encoding='utf-8'); temporary.replace(saved_file)
        session.mark_saved(state['id'])
        status.set('Сохранено: '+state['id'])
    def reset():
        if not state['id']:return
        state['slots']=session.reset(state['id'],catalog[state['id']]); update()
    ttk.Button(window,text='Сохранить — Ctrl+S',command=save).pack(pady=5)
    ttk.Button(window,text='Сбросить к исходному — Ctrl+R',command=reset).pack()
    large_step=tk.BooleanVar(value=False)
    ttk.Checkbutton(window,text='Крупный шаг',variable=large_step).pack()
    def change_multiplier(index, direction):
        if state['id']:
            step = .25 if large_step.get() else .05
            adjust_multiplier(state['slots'], catalog[state['id']]['slots'], index, step * direction)
            update()

    for index, name, keys in ((3, 'Размер', SIZE_KEYS), (4, 'Скорость', VELOCITY_KEYS)):
        buttons = ttk.Frame(window)
        buttons.pack(pady=4)
        for key, direction in keys:
            action = 'меньше' if direction < 0 else 'больше'
            ttk.Button(buttons, text=f'{name} {action} (Ctrl+{key})',
                       command=lambda index=index, direction=direction: change_multiplier(index, direction)).pack(side='left', padx=2)

    instructions = (
        'Экипируйте оружие. Горячие клавиши действуют, пока активно окно игры.\n'
        'X: Ctrl+Z / Ctrl+X   Y: Ctrl+C / Ctrl+V   Z: Ctrl+B / Ctrl+N (− / +).\n'
        'Шаг XYZ — 0,5 или 2,5. Шаг размера и скорости — 0,05 или 0,25.\n'
        'Скорость 1,0 соответствует исходной скорости частиц.\n'
        'Ctrl+S сохраняет параметры оружия. Смена оружия отменяет ручные правки без сохранения.\n'
        'Ctrl+R возвращает значения каталога. Чтобы закрепить сброс, нажмите Ctrl+S.'
    )
    ttk.Label(window, text=instructions, justify='left', wraplength=630).pack(padx=12, pady=10)
    ttk.Label(window,textvariable=status,wraplength=630).pack()
    ttk.Label(window,textvariable=diagnostic,wraplength=630).pack()
    def poll():
        if process.poll() is not None:window.destroy();return
        pawn,item,sequence,effect_count,refresh_count,actor,calls=live.equipped()
        diagnostic.set(f'Эффектов: {effect_count}; обновлений: {refresh_count}; '+('эффект создан' if actor else 'ожидание эффекта')+(' | свой персонаж не определён' if calls and not sequence else ''))
        if time.monotonic()-state['logged']>2:
            state['logged']=time.monotonic()
            log_event('telemetry',pawn=pawn,item=item,sequence=sequence,effects=effect_count,refreshes=refresh_count,actor=actor,calls=calls)
        if sequence != state['sequence']:
            state['sequence']=sequence;state['seen']=time.monotonic()
            if str(item)!=state.get('observed'):
                state['observed']=str(item);choose(str(item))
        elif time.monotonic()-state['seen']>2 and state.get('observed') is not None:
            state['observed']=None;choose('0')
        pid=W.DWORD(); U.GetWindowThreadProcessId(U.GetForegroundWindow(),C.byref(pid))
        down={k for k in 'ZXCVBNSRGHJK' if U.GetAsyncKeyState(ord(k)) & 0x8000}
        if pid.value==process.pid and hotkeys_enabled(U.GetAsyncKeyState(0x11)&0x8000,U.GetAsyncKeyState(0x10)&0x8000,U.GetAsyncKeyState(0x12)&0x8000):
            if state['id']:
                step=2.5 if large_step.get() else .5
                for key,axis,direction in KEYS:
                    if key in down:
                        move(state['slots'],catalog[state['id']]['slots'],axis,step*direction);update()
                for index, keys in ((3, SIZE_KEYS), (4, VELOCITY_KEYS)):
                    for key, direction in keys:
                        if key in down:
                            change_multiplier(index, direction)
                if 'S' in down-pressed:save()
                if 'R' in down-pressed:reset()
        pressed.clear();pressed.update(down)
        window.after(80,poll)
    def close():
        if process.poll() is None:
            live.write(live.buffer,bytes(4))
        K.CloseHandle(live.handle);window.destroy()
    window.protocol('WM_DELETE_WINDOW',close);poll();window.mainloop()

if __name__=='__main__':
    try:
        if sys.argv[1:] == ['--standard-user']:
            if C.windll.shell32.IsUserAnAdmin():
                raise RuntimeError('Откройте пользовательский dev-ярлык из обычного Проводника Windows.')
            main('L2DevUser.exe')
        elif not C.windll.shell32.IsUserAnAdmin():
            result=C.windll.shell32.ShellExecuteW(None,'runas',sys.executable,'"'+str(Path(__file__).resolve())+'"',str(SYSTEM),1)
            if result <=32:raise RuntimeError('Для dev-клиента нужны права администратора; подтвердите запрос Windows при запуске ярлыка')
        else:
            main()
    except Exception as error:
        WORK.mkdir(exist_ok=True);(WORK/'live-error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        messagebox.showerror('Свечение оружия',str(error))
