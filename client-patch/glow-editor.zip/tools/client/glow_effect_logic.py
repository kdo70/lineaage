"""Keyboard and paired-effect rules shared by the live UI and checks."""
KEYS = [('Z',0,-1),('X',0,1),('C',1,-1),('V',1,1),('B',2,-1),('N',2,1)]
SIZE_KEYS = [('G',-1),('H',1)]

def hotkeys_enabled(ctrl,shift,alt):
    return bool(ctrl and shift and not alt)

def move(slots, originals, axis, delta):
    if originals[0] is not None:
        slots[0][axis] += delta
    if originals[1] is not None:
        # Reflect the displacement across the local XZ plane; keep retail baselines.
        slots[1][axis] += -delta if axis == 1 else delta

def resize(slots, originals, delta):
    for slot, original in zip(slots, originals):
        if original is not None:
            slot[3] = min(100.0,max(0.01,round(slot[3]+delta,6)))

class EffectSessionCache:
    """Last manually edited XYZ/size per effect; reset overrides apply per weapon."""
    def __init__(self, path=None):
        self.path=path
        self.effects={}
        self.drafts={}
        self.reset_items=set()
        self.flush()

    @staticmethod
    def defaults(data):
        return [list(slot) if slot is not None else [0,0,0,1,1] for slot in data['slots']]

    def select(self,item,data,saved):
        if item in self.reset_items:
            return self.defaults(data)
        slots=[list(slot) if slot is not None else [0,0,0,1,1]
               for slot in self.drafts.get(item,saved.get(item,data['slots']))]
        for index,effect in enumerate(data['effects']):
            cached=self.effects.get(effect.casefold())
            if cached is not None and data['slots'][index] is not None:
                slots[index][:4]=cached[:]
                if index==1:slots[index][1]=-slots[index][1]
        return slots

    def remember(self,item,data,slots):
        self.reset_items.discard(item)
        self.drafts[item]=[slot[:] for slot in slots]
        seen=set()
        for index,effect in enumerate(data['effects']):
            key=effect.casefold()
            if not key or key in seen or data['slots'][index] is None:continue
            canonical=slots[index][:4]
            if index==1:canonical[1]=-canonical[1]
            self.effects[key]=canonical
            seen.add(key)
        self.flush()

    def reset(self,item,data):
        self.reset_items.add(item)
        slots=self.defaults(data)
        self.drafts[item]=[slot[:] for slot in slots]
        self.flush()
        return slots

    def flush(self):
        if self.path is None:return
        import json
        temporary=self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'effects':self.effects,'reset_items':sorted(self.reset_items)},indent=2),encoding='utf-8')
        temporary.replace(self.path)
