"""Keyboard and paired-effect rules shared by the live UI and checks."""
KEYS = [('Z',0,-1),('X',0,1),('C',1,-1),('V',1,1),('B',2,-1),('N',2,1)]
SIZE_KEYS = [('G',-1),('H',1)]
VELOCITY_KEYS = [('J',-1),('K',1)]

def hotkeys_enabled(ctrl,shift,alt):
    return bool(ctrl and not shift and not alt)

def move(slots, originals, axis, delta):
    for slot, original in zip(slots, originals):
        if original is not None:
            slot[axis] += delta

def resize(slots, originals, delta):
    adjust_multiplier(slots, originals, 3, delta)

def adjust_multiplier(slots, originals, index, delta):
    for slot, original in zip(slots, originals):
        if original is not None:
            slot[index] = min(100.0, max(0.01, round(slot[index] + delta, 6)))

class EffectPositionSession:
    """Select saved positions and keep resets active for the current session."""

    def __init__(self):
        self.reset_items = set()

    def select(self, item, data, saved):
        slots = data['slots'] if item in self.reset_items else saved.get(item, data['slots'])
        return [list(slot) if slot is not None else [0, 0, 0, 1, 1] for slot in slots]

    def reset(self, item, data):
        self.reset_items.add(item)
        return self.select(item, data, {})

    def mark_saved(self, item):
        self.reset_items.discard(item)
