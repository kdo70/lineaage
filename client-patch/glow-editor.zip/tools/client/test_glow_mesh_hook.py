"""Execute the live x86 hook with local and remote pawns and paired effects."""
import ast, struct, sys
from pathlib import Path
from types import SimpleNamespace
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools/python'))
from keystone import Ks,KS_ARCH_X86,KS_MODE_32
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
from glow_effect_logic import KEYS,move,resize,hotkeys_enabled
tree=ast.parse((root/'tools/client/glow_mesh_live.py').read_text(encoding='utf-8'))
expression=next(n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='assembly' for t in n.targets))
assembly=eval(compile(ast.Expression(expression),'hook','eval'),{'self':SimpleNamespace(buffer=0x200000,base=0x100000),'trampoline':0x100900})
code=bytes(Ks(KS_ARCH_X86,KS_MODE_32).asm(assembly,0x100000)[0])
scenarios=0
for local in (False,True):
 for match in (False,True):
  for count in (0,2,17):
    u=Uc(UC_ARCH_X86,UC_MODE_32)
    u.mem_map(0x100000,0x20000)
    for addr in (0x200000,0x300000,0x400000):u.mem_map(addr,0x2000)
    u.mem_write(0x100000,code)
    u.mem_write(0x1121b1,bytes.fromhex('8b8100010000c3'))
    u.mem_write(0x113da9,bytes.fromhex('baefbeadde' 'c3'))
    refreshed=[]
    def refresh(uc,address,size,data):
        if address==0x113da9:
            effect=uc.reg_read(UC_X86_REG_ECX)
            refreshed.append((effect,bytes(uc.mem_read(effect+0x30,20))))
            uc.mem_write(effect+8,struct.pack('<I',0x200800))
    u.hook_add(UC_HOOK_CODE,refresh)
    u.mem_write(0x100900,b'\xc3')
    u.mem_write(0x200000,struct.pack('<I10f',100,*range(1,11)))
    u.mem_write(0x300100,struct.pack('<I',int(local)))
    u.mem_write(0x3006a0,struct.pack('<I',100 if match else 200))
    u.mem_write(0x3016a0,struct.pack('<II',0x200200,count))
    u.mem_write(0x200200,struct.pack('<II',0x200300,0x200400))
    for slot,addr in enumerate((0x200300,0x200400)):
        u.mem_write(addr+4,struct.pack('<I',0x300000))
        u.mem_write(addr+0x20,struct.pack('<I',slot+1))
    u.mem_write(0x400800,struct.pack('<I',0x100800))
    registers={UC_X86_REG_EAX:77,UC_X86_REG_EBX:88,UC_X86_REG_ECX:0x300000,UC_X86_REG_EDX:99,UC_X86_REG_ESI:111,UC_X86_REG_EDI:222,UC_X86_REG_EBP:333}
    for reg,value in registers.items():u.reg_write(reg,value)
    u.reg_write(UC_X86_REG_EFLAGS,0x246)
    u.reg_write(UC_X86_REG_ESP,0x400800)
    u.emu_start(0x100000,0x100800,count=500)
    for slot,addr in enumerate((0x200300,0x200400)):
        expected=struct.pack('<5f',*range(1+slot*5,6+slot*5)) if local and match and count==2 else bytes(20)
        assert bytes(u.mem_read(addr+0x30,20))==expected,(local,match,count,slot)
    telemetry=struct.unpack('<III',u.mem_read(0x200040,12))
    assert telemetry==((0x300000,100 if match else 200,1) if local else (0,0,0))
    expected_refresh=2 if local and match and count==2 else 0
    assert len(refreshed)==expected_refresh
    assert struct.unpack('<I',u.mem_read(0x200050,4))[0]==expected_refresh
    for reg,value in registers.items():assert u.reg_read(reg)==value
    assert u.reg_read(UC_X86_REG_ESP)==0x400804
    assert u.reg_read(UC_X86_REG_EFLAGS)==0x246
    # A second frame with unchanged values must not destroy/recreate actors again.
    u.reg_write(UC_X86_REG_ESP,0x400800)
    u.emu_start(0x100000,0x100800,count=500)
    assert len(refreshed)==expected_refresh
    scenarios+=1
for key,axis,direction in KEYS:
    original=[[1,2,3,1,1],[-1,-2,-3,1,1]]
    slots=[v[:] for v in original]
    move(slots,original,axis,.5*direction)
    assert slots[0][axis]-original[0][axis]==.5*direction
    assert slots[1][axis]-original[1][axis]==.5*direction*(-1 if axis==1 else 1)
    move(slots,original,axis,-.5*direction)
    assert slots==original
original=[[1,2,3,1,1],[-1,-2,-3,1,1]]
slots=[v[:] for v in original]
resize(slots,original,.05)
assert slots[0][3]==slots[1][3]==1.05
resize(slots,original,-.05)
assert slots==original
resize(slots,original,-1000)
assert slots[0][3]==slots[1][3]==.01
resize(slots,original,1000)
assert slots[0][3]==slots[1][3]==100
for ctrl in (False,True):
 for shift in (False,True):
  for alt in (False,True):
    assert hotkeys_enabled(ctrl,shift,alt)==(ctrl and shift and not alt)
print(f'{scenarios} x86 scenarios passed, including rebuild calls and unchanged-frame checks; keyboard/mirroring/size checks passed')
