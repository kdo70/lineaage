"""Retail weapon mesh preparation and live developer launcher."""
from pathlib import Path
import argparse, csv, hashlib, json, shutil, subprocess, struct, time
from xml.etree import ElementTree
from glow_effect_assignment import assignments, effect_values, write_values

ROOT = Path(__file__).resolve().parents[2]
SYSTEM = ROOT / 'client/build/system'
WORK = ROOT / 'tools/client/glow-mesh'
VENDOR = ROOT / 'tools/vendor/weapon-audit'
EXCEPTIONS = {8190, 8689, *range(6611, 6622)}

def run(*args):
    subprocess.run([str(a) for a in args], check=True, capture_output=True)

def decode(dat, stem):
    run(VENDOR/'l2encdec/l2encdec.exe', '-d', dat, str(stem)+'.dec')
    run(VENDOR/'l2asm-disasm/l2disasm.exe', '-d', VENDOR/'l2asm-disasm/DAT_defs/Interlude/weapongrp.ddf', '-e', str(stem)+'.ddf', str(stem)+'.dec', str(stem)+'.txt')
    return Path(str(stem)+'.txt').read_bytes().splitlines()

def prepare():
    WORK.mkdir(exist_ok=True)
    source = SYSTEM/'weapongrp.dat'
    original = WORK/'weapongrp.original.dat'
    if not original.exists():
        shutil.copy2(source, original)
    if (WORK/'prepared.dat').exists():
        (WORK/'previous-prepared.sha256').write_text(hashlib.sha256((WORK/'prepared.dat').read_bytes()).hexdigest())
    lines = decode(original, WORK/'original')
    head = lines[0].split(b'\t'); ix = {s.decode(): i for i,s in enumerate(head)}
    rows=[dict(zip(ix,line.decode().split('\t'))) for line in lines[1:]]
    additions=assignments(rows,EXCEPTIONS)
    by_item={}
    for addition in additions:by_item.setdefault(addition['id'],[]).append(addition)
    result = [lines[0]]; catalog = {}; changed = []
    for line in lines[1:]:
        cells = line.split(b'\t'); item = int(cells[ix['id']])
        protected = item in EXCEPTIONS or cells[ix['is_hero']] == b'1'
        if not protected:
            for key in ('rangeA', 'rangeB'):
                if cells[ix[key]].lower() == b'lineageweapons.rangesample':
                    changed.append((item,key,cells[ix[key]].decode()))
                    cells[ix[key]] = b''
        row={key:cells[n].decode() for key,n in ix.items()}
        values=effect_values(row)
        for addition in by_item.get(item,[]):
            slot=addition['slot'];row['eff'+'AB'[slot]]=addition['effect']
            if values[slot][3]<=0:values[slot][3]=1.0
            if values[slot][4]<=0:values[slot][4]=1.0
        if item in by_item:write_values(row,values)
        cells=[row[key].encode() for key in ix]
        slots=[values[n] if row['eff'+s] else None for n,s in enumerate(('A','B'))]
        if not protected:
            catalog[str(item)] = {'slots': slots, 'mesh': cells[ix['wpn_mesh[0]']].decode(), 'effects':[cells[ix['eff'+s]].decode() for s in ('A','B')]}
        if protected:
            assert b'\t'.join(cells) == line
        result.append(b'\t'.join(cells))
    text = b'\r\n'.join(result)+b'\r\n'
    (WORK/'prepared.txt').write_bytes(text)
    run(VENDOR/'l2asm-disasm/l2asm.exe','-d',WORK/'original.ddf',WORK/'prepared.txt',WORK/'prepared.bin')
    run(VENDOR/'l2encdec/l2encdec.exe','-e','413',WORK/'prepared.bin',WORK/'prepared.dat')
    verify = decode(WORK/'prepared.dat', WORK/'verify')
    assert verify == result, 'DAT readback differs'
    (WORK/'catalog.json').write_text(json.dumps(catalog, indent=2), encoding='utf-8')
    (WORK/'removed.json').write_text(json.dumps(changed, indent=2), encoding='utf-8')
    (WORK/'effect-assignments.json').write_text(json.dumps(additions,indent=2),encoding='utf-8')
    print(f'Prepared {len(result)-1} rows; removed {len(changed)} meshes; weapons with effects: {sum(any(v["slots"]) for v in catalog.values())}')

def install():
    assert (WORK/'prepared.dat').exists(), 'Run prepare first'
    source=SYSTEM/'weapongrp.dat'
    if source.read_bytes() != (WORK/'prepared.dat').read_bytes():
        previous=(WORK/'previous-prepared.sha256').read_text() if (WORK/'previous-prepared.sha256').exists() else ''
        assert source.read_bytes() == (WORK/'weapongrp.original.dat').read_bytes() or hashlib.sha256(source.read_bytes()).hexdigest()==previous, 'Client table changed after preparation'
        shutil.copy2(WORK/'prepared.dat',source)
    run(VENDOR/'l2encdec/l2encdec.exe','-d',SYSTEM/'l2.ini',WORK/'l2.dec.ini')
    ini=(WORK/'l2.dec.ini').read_bytes()
    assert b'[URL]' in ini, 'Unknown INI encoding'
    (SYSTEM/'devmode.ini').write_bytes(ini)
    # Shortcuts stay in the workspace and launch all developer tooling automatically.
    script=ROOT/'tools/client/create_glow_shortcuts.ps1'
    run('powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',script)
    print('Installed table, developer INI and two shortcuts in client/build')

def bake(dual_shop=None):
    dual_ids = set()
    if dual_shop:
        dual_ids = {entry.attrib['id'] for entry in ElementTree.parse(dual_shop).findall('./item/production')}
        assert dual_ids, 'Dual shop has no products'
    seen_duals = set()
    saved=json.loads((WORK/'effect-positions.json').read_text(encoding='utf-8'))
    lines=(WORK/'prepared.txt').read_bytes().splitlines()
    head=lines[0].split(b'\t'); ix={s.decode():i for i,s in enumerate(head)}
    catalog=json.loads((WORK/'catalog.json').read_text(encoding='utf-8'))
    result=[lines[0]]
    seen_saved = set()
    for line in lines[1:]:
        cells=line.split(b'\t'); item=cells[ix['id']].decode()
        if item in dual_ids:
            cells[ix['icon[0]']] = b'icon.weapon_dual_sword_i00'
            seen_duals.add(item)
        if item in saved:
            seen_saved.add(item)
            assert item in catalog, 'Protected or unknown weapon ID'
            row={key:cells[n].decode() for key,n in ix.items()}
            all_values=effect_values(row)
            for index,(values,original) in enumerate(zip(saved[item],catalog[item]['slots'])):
                if original is None:continue
                assert len(values)==5 and all(isinstance(v,(int,float)) and abs(v)<100000 for v in values)
                all_values[index]=values
            write_values(row,all_values)
            cells=[row[key].encode() for key in ix]
        result.append(b'\t'.join(cells))
    assert seen_saved == saved.keys(), f'Missing saved IDs: {saved.keys() - seen_saved}'
    assert seen_duals == dual_ids, f'Missing dual IDs: {dual_ids - seen_duals}'
    (WORK/'baked.txt').write_bytes(b'\r\n'.join(result)+b'\r\n')
    run(VENDOR/'l2asm-disasm/l2asm.exe','-d',WORK/'original.ddf',WORK/'baked.txt',WORK/'baked.bin')
    run(VENDOR/'l2encdec/l2encdec.exe','-e','413',WORK/'baked.bin',WORK/'baked.dat')
    readback = decode(WORK/'baked.dat', WORK/'baked-check')
    assert len(readback) == len(result) and readback[0] == result[0]
    float_fields = {ix[f'junk1{slot}[{index}]'] for slot in 'AB' for index in range(5)}
    for expected, actual in zip(result[1:], readback[1:]):
        expected_cells, actual_cells = expected.split(b'\t'), actual.split(b'\t')
        assert len(expected_cells) == len(actual_cells)
        for index, (before, after) in enumerate(zip(expected_cells, actual_cells)):
            if before == after:
                continue
            assert index in float_fields, (expected_cells[ix['id']], head[index], before, after)
            single = struct.unpack('<f', struct.pack('<f', float(before)))[0]
            assert abs(single - float(after)) <= 5.1e-9, (expected_cells[ix['id']], head[index], before, after)
    print('Verified tuned table: '+str(WORK/'baked.dat'))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare','install','bake'])
    parser.add_argument('--dual-shop', type=Path, help='Use the common dual sword icon for products in this multisell when baking')
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'install': install()
    elif args.action == 'bake': bake(args.dual_shop)
