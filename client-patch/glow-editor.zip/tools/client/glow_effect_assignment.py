"""Assign missing retail effects using A/S-grade donor models and weapon families."""

def effect_values(row):
    count=int(row['wpn_mesh_cnt'])
    if count not in (1,2):return [None,None]
    raw=[float(row[f'junk1{s}[{n}]'] or 0) for s in ('A','B') for n in range(5)][:count*5]
    return [raw[i*3:i*3+3]+[raw[count*3+i],raw[count*4+i]] if i<count else None for i in range(2)]

def write_values(row,values):
    count=int(row['wpn_mesh_cnt'])
    assert count in (1,2)
    raw=[v for slot in values[:count] for v in slot[:3]]+[slot[3] for slot in values[:count]]+[slot[4] for slot in values[:count]]
    columns=[f'junk1{s}[{n}]' for s in ('A','B') for n in range(5)]
    for name,value in zip(columns,raw):row[name]=f'{value:.8f}'

def eligible(row):
    return (row['weapon_type'] in ('1','2','3','4','5','6','7','8')
            and row['handness'] in ('1','2','3','4','5','7')
            and int(row['wpn_mesh_cnt']) in (1,2) and bool(row['wpn_mesh[0]']))

def assignments(rows,excluded):
    by_id={int(r['id']):r for r in rows}
    donors=[]
    for r in rows:
        if int(r['id']) in excluded or r['is_hero']=='1' or int(r['crystal_type'])<4:continue
        for slot,s in enumerate(('A','B')):
            if r['eff'+s].startswith('LineageEffect.c_u') and r[f'wpn_mesh[{slot}]']:
                donors.append((r,slot))
    result=[]
    for row in rows:
        if int(row['id']) in excluded or row['is_hero']=='1' or not eligible(row):continue
        for slot in range(int(row['wpn_mesh_cnt'])):
            suffix='AB'[slot]
            if row['eff'+suffix]:continue
            model=row[f'wpn_mesh[{slot}]']
            same=[(r,s) for r,s in donors if r[f'wpn_mesh[{s}]'].lower()==model.lower()]
            if same:
                donor,donor_slot=min(same,key=lambda pair:(pair[0]['wpn_mesh_cnt']!='1',pair[0]['weapon_type']!=row['weapon_type'],-int(pair[0]['crystal_type']),int(pair[0]['id'])))
                rule='same-model'
            else:
                kind=row['weapon_type'];hand=row['handness']
                if kind=='1': donor_id=6372 if hand=='2' else 6364
                elif kind=='2':
                    hammer=any(token in model.lower() for token in ('hammer','meteor_shower','star_buster','karik'))
                    donor_id=7899 if hand=='2' and hammer else 2504 if hand=='1' and hammer else 6369 if hand=='2' else 6366 if hand=='4' else 6579 if float(row['matt'])>float(row['patt']) else 6365
                else:donor_id={'3':6367,'4':6370,'5':6371,'6':7575,'7':6579,'8':6364}[kind]
                donor=by_id[donor_id];donor_slot=0
                rule='caster-analogue' if kind=='7' else 'weapon-family'
            result.append({'id':int(row['id']),'slot':slot,'effect':donor['eff'+'AB'[donor_slot]],'donor':int(donor['id']),'donor_slot':donor_slot,'rule':rule})
    return result
