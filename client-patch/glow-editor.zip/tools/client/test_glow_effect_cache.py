"""Check cross-weapon inheritance, mirrored slots, defaults and session persistence."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from glow_effect_logic import EffectSessionCache

a={'effects':['LineageEffect.c_u004',''],'slots':[[1,2,3,1,.5],None]}
b={'effects':['lineageeffect.C_U004',''],'slots':[[10,20,30,2,.9],None]}
other={'effects':['LineageEffect.c_u007',''],'slots':[[11,22,33,3,.4],None]}
dual={'effects':['LineageEffect.c_u004','LineageEffect.c_u004'],'slots':[[0,4,1,1,.2],[0,-4,1,1,.3]]}
saved={'b':[[40,50,60,4,.9],None]}
original_json=json.dumps([a,b,other,dual,saved])
cache=EffectSessionCache()
assert cache.select('b',b,saved)[0]==[40,50,60,4,.9]
cache.remember('a',a,[[5,6,7,1.5,.5],[0,0,0,1,1]])
assert cache.select('b',b,saved)[0]==[5,6,7,1.5,.9]
assert cache.select('other',other,saved)[0]==[11,22,33,3,.4]
cache.remember('b',b,[[8,9,10,2.5,.9],[0,0,0,1,1]])
assert cache.select('a',a,saved)[0]==[8,9,10,2.5,.5]
assert cache.select('dual',dual,saved)==[[8,9,10,2.5,.2],[8,-9,10,2.5,.3]]
assert cache.reset('a',a)[0]==[1,2,3,1,.5]
assert cache.select('a',a,saved)[0]==[1,2,3,1,.5]
assert cache.select('b',b,saved)[0]==[8,9,10,2.5,.9]
cache.remember('b',b,[[15,16,17,3.5,.9],[0,0,0,1,1]])
assert cache.select('a',a,saved)[0]==[1,2,3,1,.5]
cache.remember('a',a,[[2,3,4,1.2,.5],[0,0,0,1,1]])
assert cache.select('a',a,saved)[0]==[2,3,4,1.2,.5]
# Taking settings from cache must not hand mutable lists back into the cache.
selection=cache.select('b',b,saved);selection[0][0]=999
assert cache.select('b',b,saved)[0]==[2,3,4,1.2,.9]
# The main hand wins when the same effect occurs twice, and each different effect is independent.
cache.remember('dual',dual,[[3,4,5,1.6,.2],[3,-4,5,1.6,.3]])
assert cache.select('a',a,saved)[0]==[3,4,5,1.6,.5]
mixed={'effects':['LineageEffect.c_u004','LineageEffect.c_u007'],'slots':dual['slots']}
cache.remember('mixed',mixed,[[6,7,8,1.7,.2],[9,-10,11,1.8,.3]])
assert cache.select('a',a,saved)[0]==[6,7,8,1.7,.5]
assert cache.select('other',other,saved)[0]==[9,10,11,1.8,.4]
assert json.dumps([a,b,other,dual,saved])==original_json
work=Path(__file__).resolve().parent/'glow-mesh'
with TemporaryDirectory(dir=work) as folder:
    path=Path(folder)/'cache.json'
    session=EffectSessionCache(path)
    session.remember('a',a,[[5,6,7,1.5,.5],[0,0,0,1,1]])
    assert json.loads(path.read_text())['effects']=={'lineageeffect.c_u004':[5,6,7,1.5]}
    session.reset('a',a)
    assert json.loads(path.read_text())['reset_items']==['a']
    restarted=EffectSessionCache(path)
    assert restarted.select('a',a,{})[0]==[1,2,3,1,.5]
    assert json.loads(path.read_text())['effects']=={}
print('Effect cache checks passed: latest edits, per-effect isolation, mirroring, velocity, reset, saved fallback, file and new session')
