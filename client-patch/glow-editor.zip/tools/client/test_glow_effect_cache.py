"""Check equipment selection, reset isolation and saving across sessions."""
from glow_effect_logic import EffectPositionSession, adjust_multiplier

effect = 'LineageEffect.c_u004'
a = {'effects': [effect, ''], 'slots': [[1, 2, 3, 1, .5], None]}
b = {'effects': [effect, effect], 'slots': [[10, 20, 30, 2, .9], [10, -20, 30, 2, .8]]}
saved = {'b': [[40, 50, 60, 4, .9], [40, -50, 60, 4, .8]]}
session = EffectPositionSession()

draft = session.select('a', a, saved)
draft[0][0] = 999
assert session.select('b', b, saved) == saved['b']
assert session.select('a', a, saved) == [a['slots'][0], [0, 0, 0, 1, 1]]

reset = session.reset('b', b)
assert reset == b['slots']
assert session.select('b', b, saved) == b['slots']
assert session.select('a', a, saved)[0] == a['slots'][0]
assert EffectPositionSession().select('b', b, saved) == saved['b']
assert saved['b'][0][0] == 40

reset[0][0] = 12
saved['b'] = reset
session.mark_saved('b')
assert session.select('b', b, saved) == reset
assert EffectPositionSession().select('b', b, saved) == reset
assert b['slots'][0][0] == 10

single = session.select('a', a, saved)
adjust_multiplier(single, a['slots'], 4, .05)
assert single == [[1, 2, 3, 1, .55], [0, 0, 0, 1, 1]]
pair = session.select('b', b, saved)
adjust_multiplier(pair, b['slots'], 4, -.25)
assert pair == [[12, 20, 30, 2, .65], [10, -20, 30, 2, .55]]
assert session.reset('b', b) == b['slots']
print('Saved position, catalog fallback, reset and re-equip checks passed')
