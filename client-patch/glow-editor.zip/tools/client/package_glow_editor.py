"""Archive reviewed editor sources and base data without user tuning or session files."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root=Path(__file__).resolve().parents[2]
files=[root/'tools/client'/name for name in (
    'glow_mesh.py','glow_mesh_live.py','glow_effect_logic.py','glow_effect_assignment.py',
    'create_glow_shortcuts.ps1','test_glow_mesh_hook.py','test_glow_effect_cache.py',
    'test_glow_effect_dat.py','package_glow_editor.py')]
files += [root/'tools/client/glow-mesh'/name for name in (
    'catalog.json','prepared.txt','prepared.dat','original.ddf','weapongrp.original.dat','effect-assignments.json')]
target=root/'build/client-patch'
target.mkdir(exist_ok=True)
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=target/'glow-editor.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as output:
    for file in files:output.write(file,file.relative_to(root).as_posix())
    output.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(check.read(name)).hexdigest()==digest
    assert not any(name.endswith(('effect-positions.json','effect-session-cache.json')) for name in check.namelist())
shutil.copy2(root/'client/build/system/weapongrp.dat',target/'system/weapongrp.dat')
print('Packaged editor sources/base data and current weapon DAT; user tuning excluded')
